fetch('https://example.com/delete-item/' + id, {
  method: 'DELETE',
})